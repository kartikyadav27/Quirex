import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import NavBar from "./components/landingComponents/NavBar";
const NotFound = (() => {
    const Navigate = useNavigate();
    useEffect(() => {
        // Navigate("/Login");

    },[])
    return (
        <>
        <NavBar/>
       <div className="row">
        <div className="col-sm-2"></div>
        <div className="col-sm-8">
            <h1 className="text-center text-danger">404 Not Found :(</h1> <br />
            <h3 className="text-center"><b>Oops, Login your Account <b>&rarr;</b></b></h3>
        </div>
        <div className="col-sm-2"></div>
       </div>
        </>
    )
})
export default NotFound