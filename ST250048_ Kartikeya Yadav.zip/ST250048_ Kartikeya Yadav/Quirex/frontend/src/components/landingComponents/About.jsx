import React from 'react'
import NavBar from './NavBar'
const About = () => {
  return (
    <div>
        <NavBar/>
      About
    </div>
  )
}

export default About
