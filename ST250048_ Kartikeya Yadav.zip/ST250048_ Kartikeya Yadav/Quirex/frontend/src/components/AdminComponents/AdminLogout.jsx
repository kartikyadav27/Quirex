import React from 'react'

const AdminLogout = () => {
  return (
    <div>
      AdminLogout
    </div>
  )
}

export default AdminLogout
