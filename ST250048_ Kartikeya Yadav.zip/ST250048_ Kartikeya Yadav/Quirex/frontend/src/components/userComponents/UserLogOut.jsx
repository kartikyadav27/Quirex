import React from 'react'

const UserLogOut = () => {
  return (
    <div>
      UserLogOut
    </div>
  )
}

export default UserLogOut
