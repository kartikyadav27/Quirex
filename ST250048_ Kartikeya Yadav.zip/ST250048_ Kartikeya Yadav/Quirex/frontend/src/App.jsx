import Aos from 'aos';
import 'aos/dist/aos.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.js';
import { useEffect, useState } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import './App.css';
import AddProperty from './components/AdminComponents/AddProperty';
import AdminContactUsList from './components/AdminComponents/AdminContactUsList';
import AdminProfile from './components/AdminComponents/AdminProfile';
import AdminPropertyList from './components/AdminComponents/AdminPropertyList';
import AdminSoldProperty from './components/AdminComponents/AdminSoldProperty';
import UserList from './components/AdminComponents/UserList';
import About from './components/landingComponents/About';
import Footer from './components/landingComponents/Footer';
import Home from './components/landingComponents/Home';
import Login from './components/landingComponents/Login';
import Property from './components/landingComponents/Property';
import Services from './components/landingComponents/Services';
import TopNavbar from './components/landingComponents/TopNavbar';
import UserRegister from './components/landingComponents/UserRegister';
import UserBoughtList from './components/userComponents/UserBoughtList';
import UserProfile from './components/userComponents/UserProfile';
import NotFound from './NotFound';
function App() {
   const location=useLocation()
  const [userData, setUserData] = useState(null);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("userInfo"));
    setUserData(user);
  }, [location?.pathname])
  useEffect(() => {
    Aos.init({
      offset: 200,
      duration: 600,
      easing: 'ease-in-sine',
      delay: 100,
    });
  })
  return (
    <>
      
      <TopNavbar />
      {/* <Navbar /> */}
      <Routes>
        {/* landing page router */}
        <Route path='/' element={<Home />} />
        <Route path='/about' element={<About />} />
        <Route path='/services' element={<Services />} />
        <Route path='/property' element={<Property />} />
        <Route path='/register' element={<UserRegister />} />
        <Route path='/login' element={<Login />} />
        {/* admin Section  */}
        {userData?.userType == "admin" &&
          <>
            <Route path='/admin-add' element={<AddProperty />} />
            <Route path='/admin-list' element={<AdminPropertyList />} />
            <Route path='/admin-sold' element={<AdminSoldProperty />} />
            <Route path='/admin-user' element={<UserList />} />
            <Route path='/admin-profile' element={<AdminProfile />} />
            <Route path='/admin-contact' element={<AdminContactUsList />} />
          </>
        }
        {/* User Route */}
        {userData?.userType == "user" &&
          <>
            <Route path='/user-property' element={<Property />} />
            <Route path='/user-bought' element={<UserBoughtList />} />
            <Route path='/user-profile' element={<UserProfile />} />
          </>
        }
        <Route path="*" element={<NotFound/>}/>
      </Routes>
      <Footer />
    </>
  )
}

export default App
